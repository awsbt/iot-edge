package main

import (
	b64 "encoding/base64"
	"crypto"
	"crypto/x509"
	"errors"
	"flag"
	"fmt"
	"log"
	"net/url"
	"os"

	"github.com/ForgeRock/iot-edge/v7/pkg/builder"
	"github.com/ForgeRock/iot-edge/v7/pkg/thing"
	
	"dinpe/uipath"
)

	type TPMData struct {
		KeyPublic		string
		KeyPrivate		string
		Certificate		string
	}

	type FRData struct {
		amURL		string
		realm		string
		audience	string
		authTree	string
		thingName	string
		signer		crypto.Signer
		certs		[]*x509.Certificate
	}
		

////////////////////////////////////////
// function decodePrivateKey
//		Parameter #1:	the base64 encoded private string
//		Return:  signer to be used for signing, and any possible error
//
// example string: 
// MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgw9rAMaNcP7cA0e5SECc4Tk1PDQEY66ml9y9+6E8fmR6hRANCAAQ3sy05tV/3YUlPBi9jZm9NVPeuBmntrtcO3NP/1HDsgLsTZsqKHD6KWIeJNRQnONcriWVaIcZYTKNykyCVUz93
//


func decodePrivateKey(key string) (s crypto.Signer, e error) {
	var err error
	block, _ := b64.StdEncoding.DecodeString(key)
	if block == nil {
		return nil, fmt.Errorf("unable to decode key")
	}
	
	privateKey, err := x509.ParsePKCS8PrivateKey(block)
	if err != nil {
		return nil, err
	}
	
	s, e =  privateKey.(crypto.Signer), nil

	return s,e
}


////////////////////////////////////////
// function decodeCertificates
//		Parameter #1:	the base64 encoded certificate string
//		Return:  certificate array, and any possible error
//
// example parameter:
// MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgw9rAMaNcP7cA0e5SECc4Tk1PDQEY66ml9y9+6E8fmR6hRANCAAQ3sy05tV/3YUlPBi9jZm9NVPeuBmntrtcO3NP/1HDsgLsTZsqKHD6KWIeJNRQnONcriWVaIcZYTKNykyCVUz93
//


func decodeCertificates(certs string) (c []*x509.Certificate, e error) {

	block, _ := b64.StdEncoding.DecodeString(certs)
	c, e =  x509.ParseCertificates(block)
	
	// for debugging:  print info about certificate
	// fmt.Println("Certificate")
	// fmt.Printf("  Issuer: %s\n",c[0].Issuer)
	// fmt.Printf("  Subject: %s\n",c[0].Subject)
	// fmt.Printf("  Not Before: %s\n",c[0].NotBefore)
	// fmt.Printf("  Not After: %s\n",c[0].NotAfter)
	// pkBytes, err := x509.MarshalPKIXPublicKey(c[0].PublicKey)
	// if err != nil {
	// 	fmt.Printf("  Public Key: %s\n",b64.StdEncoding.EncodeToString([]byte(pkBytes)))
	// }
	
	return c, e
}


////////////////////////////////////////
// function getForgeRockAccessToken
//		Parameter #1:	the TPMdata structure, containing base64 encoded strings
//		Parameter #2:	the frData structure
//		Return:  the value of the asset token or 'NO MATCH', and any possible error
//

func getForgeRockAccessToken(tpmData TPMData, frData FRData) (retString string, err error) {

	// parse the URL for AM 
	u, err := url.Parse(frData.amURL)
	if err != nil {
		return "NO MATCH", err
	}
	
	// get a signer based on the private key
	var signer crypto.Signer
	signer, err = decodePrivateKey(tpmData.KeyPrivate)
		if err != nil {
			return "NO MATCH", err
		}

	// get the certificate array
	var certs []*x509.Certificate
	certs, err = decodeCertificates(tpmData.Certificate)
		if err != nil {
			return "NO MATCH", err
		}

	// use key thumbprint as key id
	keyID, err := thing.JWKThumbprint(signer)
	if err != nil {
		return "NO MATCH", err
	}
	
	// create a builder 
	builder := builder.Thing().
		ConnectTo(u).
		InRealm(frData.realm).
		WithTree(frData.authTree).
		AuthenticateThing(frData.thingName, frData.audience, keyID, signer, nil).
		RegisterThing(certs, nil)

	fmt.Printf("Creating Thing %s... \n", frData.thingName)
	device, err := builder.Create()
	if err != nil {
		return "NO MATCH", err
	}
	fmt.Printf("Done\n")

	fmt.Printf("Requesting access token... ")
	tokenResponse, err := device.RequestAccessToken("publish")
	if err != nil {
		return "NO MATCH", err
		}
	fmt.Println("Done")
	token, err := tokenResponse.AccessToken()
	if err != nil {
		return "NO MATCH", err
	}
	fmt.Println("Access token:", token)
	expiresIn, err := tokenResponse.ExpiresIn()
	if err != nil {
		return "NO MATCH", err
	}
	fmt.Println("Expires in:", expiresIn)
	scopes, err := tokenResponse.Scope()
	if err != nil {
		return "NO MATCH", err
	}
	fmt.Println("Scope(s):", scopes)

return "NO MATCH", err
}

////////////////////////////////////////
// function getTPMData
//		Parameter #1:	the refresh token to use to get TPMData
//		Parameter #2:	the prefix to use on key lookups
//		Return:  the TPMData structure or 'NO MATCH' and any error
//

func getTPMData(refreshToken string, keyPrefix string) (tpmData TPMData, err error) {

	// initialize return structure
	tpmData = TPMData {
		KeyPublic:		"",
		KeyPrivate:		"",
		Certificate:	""	}
	
	// authenticate to the system
	accessToken, err := uipath.GetAccessToken(refreshToken)

    if err != nil {
		return tpmData, err
		}
	
	// get folder to use
	folderId := uipath.GetFolderId(accessToken, "NPE")
	
	if folderId != "ERROR" {

		// retrieve (base64 encoded) public key
		tpmData.KeyPublic = uipath.FetchAssetStringValue(accessToken, folderId, keyPrefix+"-TPM-PublicKey")
		if tpmData.KeyPublic == "NO MATCH" {
			return tpmData, errors.New("Error:  could not find asset "+keyPrefix+"-TPM-PublicKey")
		}
		
		// retrieve (base64 encoded) private key
		tpmData.KeyPrivate = uipath.FetchAssetStringValue(accessToken, folderId, keyPrefix+"-TPM-PrivateKey")
		if tpmData.KeyPrivate == "NO MATCH" {
			return tpmData, errors.New("Error:  could not find asset "+keyPrefix+"-TPM-PrivateKey")
		}
		
		// retrieve (base64 encoded) certificate
		tpmData.Certificate = uipath.FetchAssetStringValue(accessToken, folderId, keyPrefix+"-Certificate")
		if tpmData.Certificate == "NO MATCH" {
			return tpmData, errors.New("Error:  could not find asset "+keyPrefix+"-Certificate")
		}
		
		// optional - print the private key and the certificate
		// fmt.Print("PrivateKey=")
		// fmt.Println(tpmData.KeyPrivate)
		// fmt.Print("Certificate=")
		// fmt.Println(tpmData.Certificate)
		}
		
	return tpmData, nil
}

////////////////////////////////////////
// function getThingsAccessToken
//		Return:  error if one occured
//
// Main function for this application.  Get data stored in UIPath and
// use it to authenticate with ForgeRock IoT.
//

func getThingsAccessToken() (err error) {

	var (
		refreshToken	= flag.String("refreshToken", "C2Va1zgkfAjna0IyOsCc1n5YK_s3WkHDvmxdOS6ITSQdf", "Refresh token for UiPath")
		uiPathPrefix	= flag.String("uiPathPrefix", "DINPE-Bot", "Prefix to use for uipath lookups")
		urlString	 	= flag.String("url", "https://fr0.zte.peraton.com/am", "URL of AM or Gateway")
		realm       	= flag.String("realm", "/", "AM Realm")
		audience    	= flag.String("audience", "/", "JWT audience")
		authTree    	= flag.String("tree", "Thing-reg", "Authentication tree")
		thingName   	= flag.String("name", "00000002-0123-0123-0123-012345678901", "Thing name")
	)
	
	flag.Parse()
	
	// First - get the TPM data (public key, private key, certificate)
	tpmData, err := getTPMData(*refreshToken, *uiPathPrefix)
	
    if err != nil {
		return err
		}
	
	// create a structure to track ForgeRock info
	var frData = FRData { }
	
	frData.amURL = *urlString
	frData.realm = *realm
	frData.audience = *audience
	frData.authTree = *authTree
	frData.thingName = *thingName
	
	// get the accessToken from ForgeRock IdP
	idpAccessToken, err := getForgeRockAccessToken(tpmData, frData)

    if err != nil {
		return err
		}

	fmt.Print("AccessToken=")
	fmt.Println(idpAccessToken)
	
	return nil
}

////////////////////////////////////////
// main body
//
//

func main() {
	
	// pipe debug to standard out
	thing.DebugLogger().SetOutput(os.Stdout)

	err := getThingsAccessToken();
	if  err != nil {
		log.Fatal(err)
	}
}

