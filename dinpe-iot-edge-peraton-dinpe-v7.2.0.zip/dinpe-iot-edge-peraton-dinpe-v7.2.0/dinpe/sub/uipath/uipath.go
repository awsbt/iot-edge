package uipath

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"regexp"
)

	type AssetKeyValue struct {
		Key		string
		Value	string }
	type Asset struct {
		Name			string
		CanBeDeleted	string
		ValueScope		string
		ValueType		string	
		Value			string
		StringValue		string
		Id				int  }

////////////////////////////////////////
// function getBodyMatch
//		Parameter #1:  the body of an http request
//		Parameter #2:  the regex used to search for the match
//		Return:			the body as a string and the matched string
//	
// This function searches the body of the http response for text
//	described by the regex

func getBodyMatch(resp io.ReadCloser, regex string) (string, string) {
	
	body, err := io.ReadAll(resp)
	if err != nil {
		return "ERROR", "NO MATCH"
		}
		
	bodyString := string(body)
	r, _ := regexp.Compile(regex)
	matchingSlices := r.FindStringSubmatch(bodyString)
	
	if matchingSlices != nil {
		matchedString := matchingSlices[1]
	
		// fmt.Println("MATCH: " + matchedString)
		return bodyString, matchedString
	}
	
	return bodyString, "NO MATCH"
}

////////////////////////////////////////
// function authenticateToUIPath
//		Parameter #1:	the settings structure
//		Return:			an error if error occurs
//	
// This function takes a shared coded refresh token and requests a new access token

func GetAccessToken(refreshToken string) (accessToken string, err error) {

	// payload data for the request
	data := map[string]string{
		"grant_type": 		"refresh_token",
		"client_id": 		"8DEv1AMNXczW3y4U15LL3jYf62jK93n5" }
	data["refresh_token"] = refreshToken
	json_data, err := json.Marshal(data)

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://account.uipath.com/oauth/token", bytes.NewBuffer(json_data))
	req.Header.Set("Content-Type", "application/json")

	// make the request
	resp, err := client.Do(req)

	if err != nil {
		log.Fatal(err)
		return "NO MATCH", err
		}
	
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		fmt.Println(":::ERROR::: Could not authenticate")
		fmt.Println("RESPONSE")
		fmt.Println(resp)
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			log.Fatal(err)
			}
		fmt.Println(string(body))
		return "NO MATCH", errors.New("Error:  could not authenticate")
		}
	
	// search the body of the response for the access token
	bodyString, accessToken := getBodyMatch(resp.Body, "access_token\":\"([^\"]+)\",")
	
	// if an access token was found, return it
	if accessToken != "NO MATCH" {
		// fmt.Println("ACCESS TOKEN:" + accessToken)
		// fmt.Println(bodyString)
		return accessToken, nil
	}
	
	// otherwise, print out debugging info
	fmt.Println(":::ERROR::: Could not find access token")
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	// bodyString := string(body)
	fmt.Println(bodyString)

	return "NO MATCH", errors.New("Error:  could not authenticate")
}

////////////////////////////////////////
// function getFolderId
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folder's name
//		Return:			the folder ID as a string
//
// This function searches for a folder with the supplied name

func GetFolderId(accessToken string, folderName string) string {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://cloud.uipath.com/perspowhqzbz/Default/orchestrator_/odata/folders", nil)
	req.Header.Set("Content-Type", "application/json")
	
	// add the access token as a header
	req.Header.Set("Authorization", "Bearer "+accessToken)

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
	
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		fmt.Println(":::ERROR::: Could not get folder")
		fmt.Println("RESPONSE")
		fmt.Println(resp)
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			log.Fatal(err)
			}
		fmt.Println(string(body))
		return "ERROR"
		}
		
	// search the body of the response for the folder ID
	bodyString, folderId := getBodyMatch(resp.Body, "\"DisplayName\":\""+folderName+"\".*\"Id\":([0-9]*)")
	
	// if an access token was found, return it
	if folderId != "NO MATCH" {
		// fmt.Println("FOLDER ID:" + folderId)
		return folderId
	}

	// otherwise, print out debugging info
	fmt.Println(":::ERROR::: Could not find folder in reponse")
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	// bodyString := string(body)
	fmt.Println(bodyString)

	return "ERROR"
}


////////////////////////////////////////
// function fetchAssetStringValue
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//		Return:  the value of the asset of 'NO MATCH'
//

func FetchAssetStringValue(accessToken string, folderId string, assetName string) string {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	url := "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets?$filter=Name eq '"  +  assetName  +  "'"
	req, _ := http.NewRequest("GET", url, nil) 
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}

	// wait for response body to be fully received	
	defer resp.Body.Close()
	

	
	bodyString, assetValue := getBodyMatch(resp.Body, "\"StringValue\":\"([^\"]*)")
	if assetValue == "NO MATCH" {
		// fmt.Println(":::ASSET NOT FOUND:::")
		// fmt.Println("url = "+url)
		// fmt.Println(req)
		// fmt.Print("response = ")
		// fmt.Println(resp.StatusCode)
		// fmt.Println(" ")
		// fmt.Println("RESPONSE")
		// fmt.Println(resp)
		/// fmt.Println(bodyString)
		_ = bodyString		// ignore not used warning
		return "NO MATCH"
		}

	// fmt.Println("Asset:"+assetName)
	// fmt.Println("Value:"+assetValue)
	// fmt.Println(" ")
	
	return assetValue
	
}


