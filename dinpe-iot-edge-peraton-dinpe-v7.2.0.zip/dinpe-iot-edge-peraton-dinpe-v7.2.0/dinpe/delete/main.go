package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"regexp"
	"strings"
)

////////////////////////////////////////
// function getBodyMatch
//		Parameter #1:  the body of an http request
//		Parameter #2:  the regex used to search for the match
//	
// This function searches the body of the http response for text
//	described by the regex

func getBodyMatch(resp io.ReadCloser, regex string) string {
	
	body, err := io.ReadAll(resp)
	if err != nil {
		return "NO MATCH"
		}
		
	bodyString := string(body)
	r, _ := regexp.Compile(regex)
	matchingSlices := r.FindStringSubmatch(bodyString)
	
	if matchingSlices != nil {
		matchedString := matchingSlices[1]
	
		// fmt.Println("MATCH: " + matchedString)
		return matchedString
	}
	
	return "NO MATCH"
}

////////////////////////////////////////
// function authenticateToUIPath
//	
// This function takes a hared coded refresh token and requests a new access token

func authenticateToUIPath() string {

	// payload data for the request
	data := map[string]string{
		"grant_type": 		"refresh_token",
		"client_id": 		"8DEv1AMNXczW3y4U15LL3jYf62jK93n5",
		"refresh_token": 	"sM9ERAnObtMV3qtcmwBwQ81hkCpvZP4r4_cTjNJew9W04"	}
	json_data, err := json.Marshal(data)

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://account.uipath.com/oauth/token", bytes.NewBuffer(json_data))
	req.Header.Set("Content-Type", "application/json")

	// make the request
	resp, err := client.Do(req)

	if err != nil {
		log.Fatal(err)
		}
		
	// search the body of the response for the access token
	defer resp.Body.Close()
	accessToken := getBodyMatch(resp.Body, "access_token\":\"([^\"]+)\",")
	
	// if an access token was found, return it
	if accessToken != "NO MATCH" {
		fmt.Println("ACCESS TOKEN:" + accessToken)
		return accessToken
	}
	
	// otherwise, print out debugging info
	fmt.Println(":::ERROR::: Could not authenticate")
	fmt.Println(" ")
	fmt.Println("REQUEST")
	fmt.Println(req)
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	body, err := io.ReadAll(resp.Body)
	bodyString := string(body)
	fmt.Println(bodyString)

	// otherwise, return the word "ERROR"
	return "ERROR"
}

////////////////////////////////////////
// function getFolder
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folder's name
//
// This function searches for a folder with the supplied name

func getFolder(accessToken string, folderName string) string {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://cloud.uipath.com/perspowhqzbz/Default/orchestrator_/odata/folders", nil)
	req.Header.Set("Content-Type", "application/json")
	
	// add the access token as a header
	req.Header.Set("Authorization", "Bearer "+accessToken)

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
	
	// search the body of the response for the folder ID
	defer resp.Body.Close()
	folderId := getBodyMatch(resp.Body, "\"DisplayName\":\""+folderName+"\".*\"Id\":([0-9]*)")
	
	// if an access token was found, return it
	if folderId != "NO MATCH" {
		fmt.Println("FOLDER ID:" + folderId)
		return folderId
	}

	// otherwise, print out debugging info
	fmt.Println(":::ERROR::: Could not find folder")
	fmt.Println(" ")
	fmt.Println("REQUEST")
	fmt.Println(req)
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	body, err := io.ReadAll(resp.Body)
	bodyString := string(body)
	fmt.Println(bodyString)

	// otherwise, return the word "ERROR"
	return "ERROR"
}

////////////////////////////////////////
// function lookupAsset
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//
// This function finds a test asset

func lookupAsset(accessToken string, folderId string, assetName string) string {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	url := "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets?$filter=Name eq '"  +  assetName  +  "'"
	req, _ := http.NewRequest("GET", url, nil) 
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
		
	// search the body of the response for the folder ID
	defer resp.Body.Close()
	assetId := getBodyMatch(resp.Body, "\"Id\":([0-9]*)")
	
	// fmt.Println(" ")
	// fmt.Println("LOOKUP TEST STRING")
	// fmt.Println(req)
	// fmt.Println("RESPONSE")
	// fmt.Println(resp)
	
	if assetId != "NO MATCH" {
		fmt.Println("ASSET ID: " +assetId)
		}
	return assetId

}

////////////////////////////////////////
// function registerTestString
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//
// This function adds a test asset

func registerAsset(accessToken string, folderId string, assetName string) {

	type Asset struct {
		Name			string
		CanBeDeleted	string
		ValueScope		string
		ValueType		string	
		Value			string
		StringValue		string
		Id				int }
		
	// payload data for the request
	data := Asset{	// payload data for the request
		CanBeDeleted:	"true",
		ValueScope: 	"Global",
		ValueType: 	"KeyValueList",
		Value: 		"Test String Value",
		StringValue: 	"Test String Value"	}	
	data.Name = assetName
	json_data, err := json.Marshal(data)

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets", bytes.NewBuffer(json_data))
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
		
	fmt.Println(" ")
	fmt.Println("CREATE TEST STRING")
	fmt.Println(req)
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	
	defer resp.Body.Close()
	fmt.Println("BODY")
	body, err := io.ReadAll(resp.Body)
	bodyString := string(body)
	fmt.Println(bodyString)
}

////////////////////////////////////////
// function updateAsset
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		parameter #3:	the asset ID number
//		Parameter #4:	the asset name
//
// This function adds a test asset

func deleteAsset(accessToken string, folderId string, assetId string, assetName string) {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	url := "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets(" + assetId + ")"
	req, _ := http.NewRequest("DELETE", url, nil)
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// fmt.Println("BODY")
	// body, err := io.ReadAll(req.Body)
	// bodyString := string(body)
	// fmt.Println(bodyString)
	
	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
	}
		
	// fmt.Println(" ")
	// fmt.Println("UPDATE TEST STRING")
	// fmt.Println(req)
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	
	defer resp.Body.Close()
	//fmt.Println("Update Response:")
	body, err := io.ReadAll(resp.Body)
	bodyString := string(body)
	fmt.Println(bodyString)

}

////////////////////////////////////////
// function printAsset
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//
// This function prints a test asset

func printAsset(accessToken string, folderId string, assetName string) {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	url := "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets?$filter=Name eq '"  +  assetName  +  "'"
	req, _ := http.NewRequest("GET", url, nil) 
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
		
	// search the body of the response for the folder ID
	defer resp.Body.Close()
	
	// fmt.Println(" ")
	// fmt.Println("LOOKUP TEST STRING")
	// fmt.Println(req)
	// fmt.Println("RESPONSE")
	// fmt.Println(resp)
	
	fmt.Println("Asset:")
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	bodyString := string(body)
	fmt.Println(strings.Replace(bodyString, ",", ",\n\r  ",-1))
	
}


////////////////////////////////////////
// main body
//
//

func main() {

	// authenticate to the system
	accessToken := authenticateToUIPath()
	
	if accessToken != "ERROR" {
		// set folder
		folderId := getFolder(accessToken, "NPE")
	
		if folderId != "ERROR" {
			// lookup 
			assetName := "DINPE-TestKeyValuePair"
			// assetName = "DINPE-TestString"
			
			assetId := lookupAsset(accessToken, folderId, assetName)
			// fmt.Println(assetId)
			
			/// create or update
			if assetId != "NO MATCH" {
				fmt.Println("DELETING THIS ACCET = "+assetId)
				printAsset(accessToken, folderId, assetName)
				// delete asset
				deleteAsset(accessToken, folderId, assetId, assetName)
			}
			
		}
	}
}