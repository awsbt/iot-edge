package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

	type AssetKeyValue struct {
		Key		string
		Value	string }
	type Asset struct {
		Name			string
		CanBeDeleted	string
		ValueScope		string
		ValueType		string	
		Value			string
		StringValue		string
		Id				int  }

////////////////////////////////////////
// function getBodyMatch
//		Parameter #1:  the body of an http request
//		Parameter #2:  the regex used to search for the match
//		Return:			the body as a string and the matched string
//	
// This function searches the body of the http response for text
//	described by the regex

func getBodyMatch(resp io.ReadCloser, regex string) (string, string) {
	
	body, err := io.ReadAll(resp)
	if err != nil {
		return "ERROR", "NO MATCH"
		}
		
	bodyString := string(body)
	r, _ := regexp.Compile(regex)
	matchingSlices := r.FindStringSubmatch(bodyString)
	
	if matchingSlices != nil {
		matchedString := matchingSlices[1]
	
		// fmt.Println("MATCH: " + matchedString)
		return bodyString, matchedString
	}
	
	return bodyString, "NO MATCH"
}

////////////////////////////////////////
// function authenticateToUIPath
//		Return:		the access token as a string
//	
// This function takes a hared coded refresh token and requests a new access token

func authenticateToUIPath() string {

	// payload data for the request
	data := map[string]string{
		"grant_type": 		"refresh_token",
		"client_id": 		"8DEv1AMNXczW3y4U15LL3jYf62jK93n5",
		"refresh_token": 	"C2Va1zgkfAjna0IyOsCc1n5YK_s3WkHDvmxdOS6ITSQdf"	}
	json_data, err := json.Marshal(data)

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("POST", "https://account.uipath.com/oauth/token", bytes.NewBuffer(json_data))
	req.Header.Set("Content-Type", "application/json")

	// make the request
	resp, err := client.Do(req)

	if err != nil {
		log.Fatal(err)
		}
		
	// search the body of the response for the access token
	defer resp.Body.Close()
	bodyString, accessToken := getBodyMatch(resp.Body, "access_token\":\"([^\"]+)\",")
	
	// if an access token was found, return it
	if accessToken != "NO MATCH" {
		// fmt.Println("ACCESS TOKEN:" + accessToken)
		return accessToken
	}
	
	// otherwise, print out debugging info
	fmt.Println(":::ERROR::: Could not authenticate")
	fmt.Println(" ")
	fmt.Println("REQUEST")
	fmt.Println(req)
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	// bodyString := string(body)
	fmt.Println(bodyString)

	// otherwise, return the word "ERROR"
	return "ERROR"
}

////////////////////////////////////////
// function getFolder
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folder's name
//		Return:			the folder ID as a string
//
// This function searches for a folder with the supplied name

func getFolder(accessToken string, folderName string) string {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://cloud.uipath.com/perspowhqzbz/Default/orchestrator_/odata/folders", nil)
	req.Header.Set("Content-Type", "application/json")
	
	// add the access token as a header
	req.Header.Set("Authorization", "Bearer "+accessToken)

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
	
	// search the body of the response for the folder ID
	defer resp.Body.Close()
	bodyString, folderId := getBodyMatch(resp.Body, "\"DisplayName\":\""+folderName+"\".*\"Id\":([0-9]*)")
	
	// if an access token was found, return it
	if folderId != "NO MATCH" {
		// fmt.Println("FOLDER ID:" + folderId)
		return folderId
	}

	// otherwise, print out debugging info
	fmt.Println(":::ERROR::: Could not find folder")
	fmt.Println(" ")
	fmt.Println("REQUEST")
	fmt.Println(req)
	fmt.Println("RESPONSE")
	fmt.Println(resp)
	// bodyString := string(body)
	fmt.Println(bodyString)

	// otherwise, return the word "ERROR"
	return "ERROR"
}

////////////////////////////////////////
// function lookupAsset
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//		Return:			the assetId as a string
//
// This function finds a test asset

func lookupAsset(accessToken string, folderId string, assetName string) string {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	url := "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets?$filter=Name eq '"  +  assetName  +  "'"
	req, _ := http.NewRequest("GET", url, nil) 
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
		
	// search the body of the response for the folder ID
	defer resp.Body.Close()
	bodyString, assetId := getBodyMatch(resp.Body, "\"Id\":([0-9]*)")
	if bodyString == "ERROR" {
		log.Fatal(err)
		}
	// fmt.Println(" ")
	// fmt.Println("LOOKUP TEST STRING")
	// fmt.Println(req)
	// fmt.Println("RESPONSE")
	// fmt.Println(resp)
	
	if assetId != "NO MATCH" {
		// fmt.Println("ASSET ID: " +assetId)
		}
	return assetId

}

////////////////////////////////////////
// function createOrUpdateStringAsset
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//		Parameter #4:	the asset value
//		No Return
//
// This function adds or updates an asset

func createOrUpdateStringAsset(accessToken string, folderId string, assetName string, assetValue string) {

	action := "TBD"
	url := "TBD"
	
	// payload data for the request
	data := Asset{	// payload data for the request
		CanBeDeleted:	"true",
		ValueScope: 	"Global",
		ValueType: 		"Text" }
	data.Name = assetName
	data.StringValue = assetValue

	// see if asset already exists
	assetId := lookupAsset(accessToken, folderId, assetName)
	// fmt.Println(assetId)
			
	if assetId != "NO MATCH" {
		// updating asset
		fmt.Println("Update asset: "+assetName+"  with ID:"+assetId)
		assetIdInt, err := strconv.Atoi(assetId)
		data.Id = assetIdInt
		if err != nil {
			log.Fatal(err)
			}
		action = "PUT"
		url = "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets(" + assetId + ")"
	} else {
		// create an asset
		fmt.Println("Creating asset: "+assetName)
		action = "POST"
		url = "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets"
	}

	// payload data for the request
	json_data, err := json.Marshal(data)

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	req, _ := http.NewRequest(action, url, bytes.NewBuffer(json_data))
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// fmt.Println("REQUEST")
	// fmt.Println(req)
	// fmt.Println("BODY")
	// fmt.Println(string(json_data))

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}
		
	// fmt.Println("RESPONSE")
	// fmt.Println(resp)
	
	defer resp.Body.Close()
	// fmt.Println("BODY")
	// body, err := io.ReadAll(resp.Body)
	// bodyString := string(body)
	// fmt.Println(bodyString)
}


////////////////////////////////////////
// function printAsset
//		Parameter #1:	contents of the accessToken
//		Parameter #2:	the folderID
//		Parameter #3:	the asset name
//
// This function prints a test asset

func printAsset(accessToken string, folderId string, assetName string) {

	// create an http cient and set the content type to JSON
	client := &http.Client{}
	url := "https://cloud.uipath.com/perspowhqzbz/Default/odata/Assets?$filter=Name eq '"  +  assetName  +  "'"
	req, _ := http.NewRequest("GET", url, nil) 
	req.Header.Set("Content-Type", "application/json")

	// add the access token as a header, and the folder path
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-UIPATH-OrganizationUnitId", folderId);

	// make the request
	resp, err := client.Do(req)
	
	if err != nil {
		log.Fatal(err)
		}

	// wait for response body to be fully received	
	defer resp.Body.Close()
	
	// fmt.Println(" ")
	// fmt.Println("LOOKUP TEST STRING")
	// fmt.Println(req)
	// fmt.Println("RESPONSE")
	// fmt.Println(resp)
	
	fmt.Println("Asset:")
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	bodyString := string(body)
	fmt.Println(strings.Replace(bodyString, ",", ",\n\r  ",-1))
	
}


////////////////////////////////////////
// main body
//
//

func main() {

	// authenticate to the system
	accessToken := authenticateToUIPath()
	
	if accessToken != "ERROR" {
		// set folder
		folderId := getFolder(accessToken, "NPE")
	
		if folderId != "ERROR" {

			createOrUpdateStringAsset(accessToken, folderId, "DINPE-Bot-Certificate", "MIIBmTCCAT+gAwIBAgIUTmNbnsJAKCLJTrq+HAC4sXVc+MkwCgYIKoZIzj0EAwIwajELMAkGA1UEBhMCVUsxEDAOBgNVBAgTB0JyaXN0b2wxEDAOBgNVBAcTB0JyaXN0b2wxEjAQBgNVBAoTCUZvcmdlUm9jazEPMA0GA1UECxMGT3BlbkFNMRIwEAYDVQQDEwllczI1NnRlc3QwHhcNMjMwMjIyMDQ0MzM3WhcNMjYwMjIyMDQ0MzM3WjAvMS0wKwYDVQQDEyQwMDAwMDAwMy0wMTIzLTAxMjMtMDEyMy0wMTIzNDU2Nzg5MDEwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAATVzoTetvMiTzYhKLCsoUFA1+N8VGNox81DJNUlDFDB/2XPfIXnbmIo8neCV+IqADbtmmE+vqzibKCsCdGpgV0YMAoGCCqGSM49BAMCA0gAMEUCIGP40iHngDKiuCt0O5zDmdb6hRzFP4rFWxm8fijDbSNTAiEAoODrOJOzy/4qz6PNNevHHYlPx1MWnbHPlr29Ha5nVfw=")
			printAsset(accessToken, folderId, "DINPE-Bot-TPM-PublicKey")

			createOrUpdateStringAsset(accessToken, folderId, "DINPE-Bot-TPM-PublicKey", "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1c6E3rbzIk82ISiwrKFBQNfjfFRjaMfNQyTVJQxQwf9lz3yF525iKPJ3glfiKgA27ZphPr6s4mygrAnRqYFdGA==")
			printAsset(accessToken, folderId, "DINPE-Bot-TPM-PrivateKey")

			createOrUpdateStringAsset(accessToken, folderId, "DINPE-Bot-TPM-PrivateKey", "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgw9rAMaNcP7cA0e5SECc4Tk1PDQEY66ml9y9+6E8fmR6hRANCAAQ3sy05tV/3YUlPBi9jZm9NVPeuBmntrtcO3NP/1HDsgLsTZsqKHD6KWIeJNRQnONcriWVaIcZYTKNykyCVUz93")
			printAsset(accessToken, folderId, "DINPE-Bot-Certificate")
	
		}
	}
}