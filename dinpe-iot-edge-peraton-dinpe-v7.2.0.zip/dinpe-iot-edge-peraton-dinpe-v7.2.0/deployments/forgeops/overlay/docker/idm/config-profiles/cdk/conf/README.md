This file is a placeholder to maintain the empty CDK directory.

Files placed in this directory will override the files from the inherited IDM image.
